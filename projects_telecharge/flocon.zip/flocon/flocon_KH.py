from turtle import *

n = int(input())

penup()
setpos (-140,-50)
pendown()
speed(0)
hideturtle()

def partie_flacon(n,d):
    if n!=0:
        partie_flacon(n-1,d)
        left(60)
        partie_flacon(n-1,d)
        right(120)
        partie_flacon(n-1,d)
        left(60)
        partie_flacon(n-1,d)
    else:
        forward(d)

def complet_flacon(n,d): # n nombre des morceaux et d est la taille
    left(60)
    partie_flacon(n,d/(3**n))
    right(120)
    partie_flacon(n,d/(3**n))
    right(120)
    partie_flacon(n,d/(3**n))
    left(180)


complet_flacon(n,200)
done()