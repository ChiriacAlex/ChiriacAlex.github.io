from classe_enigma import Enigma
import typing
from PyQt5.QtWidgets import QMainWindow,QApplication,QLabel,QPushButton,QTextEdit, QWidget,QComboBox,QLineEdit
from PyQt5 import QtCore, uic
import sys


ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'

class ErrorWindow(QWidget):
    def __init__(self,message):
        super(ErrorWindow,self).__init__()
        uic.loadUi("GUI/error_message.ui",self)

        self.error = self.findChild(QLabel,'error_message')
        self.error.setText(message)
        self.setWindowModality(2)


        self.show()
    

class OptionWindow(QWidget):
    def __init__(self):
        super(OptionWindow,self).__init__()
        self.setWindowModality(2)

        uic.loadUi("GUI/otpions.ui",self)
        self.rotor_l = self.findChild(QComboBox,'rotor_left')
        self.rotor_c = self.findChild(QComboBox,'rotor_center')
        self.rotor_r = self.findChild(QComboBox,'rotor_right')
        

        self.letter_l = self.findChild(QComboBox,'letter_left')
        self.letter_c = self.findChild(QComboBox,'letter_center')
        self.letter_r = self.findChild(QComboBox,'letter_right')

        self.reflector = self.findChild(QComboBox,'reflector')

        self.cable = self.findChild(QLineEdit,'cable_text')


        self.button = self.findChild(QPushButton,'submit')


        self.show()

    def set_rotors(self,l):
        self.rotor_l.setCurrentIndex(l[0])
        self.rotor_c.setCurrentIndex(l[1])
        self.rotor_r.setCurrentIndex(l[2])

    def set_letters(self,l):
        self.letter_l.setCurrentText(l[0])
        self.letter_c.setCurrentText(l[1])
        self.letter_r.setCurrentText(l[2])
    
    def set_reflector(self,r):
        self.reflector.setCurrentIndex(r)

    def set_cable(self,text):
        self.cable.setText(text)




class UI(QMainWindow):
    def __init__(self):
        super(UI,self).__init__()

        uic.loadUi("GUI/main_window.ui",self)

        self.rotor = [3,2,1]
        self.reflecteur = 2
        self.inital_letters = ["A", "A", "A"]
        self.cable = "FT"

        self.my_buttons = []
        self.my_letters = []
        self.plaintext = ""
        self.encrypted_letter = ""

        self.button_option = self.findChild(QPushButton,'options')
        self.button_option.clicked.connect(self.open_options)

        self.text_edit = self.findChild(QTextEdit,'plain_text')
        self.text_edit.textChanged.connect(self.change_text)

        

        self.text_box = self.findChild(QLabel,'text_encrypted')
        for letter in ALPHABET:
            self.my_buttons.append(self.findChild(QPushButton,f"button_{letter}"))
            self.my_letters.append(self.findChild(QLabel,f"letter_{letter}"))

        for i in range(26):
            self.my_buttons[i].pressed.connect(lambda n = i: self.click(n))
            self.my_buttons[i].released.connect(lambda n = i: self.release_click(n))


        self.show()
    
    def click(self,letter):
        self.plaintext+=ALPHABET[letter]
        self.encrypt_word()
        self.my_letters[ALPHABET.index(self.encrypted_letter)].setStyleSheet("color: yellow;")
        self.text_edit.setText(self.plaintext)

    def release_click(self,letter):
        self.my_letters[ALPHABET.index(self.encrypted_letter)].setStyleSheet("color: white;")

    def change_text(self):
        text = self.text_edit.toPlainText()
        text = text.upper()
        new_text = ""
        for l in text:
            if l.isalpha() or l==" ":
                new_text+=l

        self.plaintext = new_text
        self.encrypt_word()

    def encrypt_word(self):
        enigma = Enigma(self.rotor[0],self.rotor[1],self.rotor[2],self.reflecteur)
        enigma.Set_Configuration_depart(self.inital_letters[0], self.inital_letters[1], self.inital_letters[2])
        enigma.Set_cablage_depart(self.cable)

        if self.plaintext!="":
            ch = ""
            for l in self.plaintext:
                if l == " ":
                    pass
                else:
                    ch += enigma.Decodagelettre(l)
            new_ch = ""
            for i in range(0, len(ch)):
                if (i%5 == 0) and (i != 0):
                    new_ch += " "
                    
                new_ch += ch[i]

            if new_ch[-1]!=" ":
                self.encrypted_letter = new_ch[-1]
            else:
                self.encrypted_letter = new_ch[-2]

            self.text_box.setText(new_ch)
        else:
            self.text_box.setText("")

    def open_options(self):
        self.option_window = OptionWindow()
        self.option_window.set_rotors([self.rotor[0]-1,self.rotor[1]-1,self.rotor[2]-1])
        self.option_window.set_letters([self.inital_letters[0], self.inital_letters[1], self.inital_letters[2]])
        self.option_window.set_reflector(self.reflecteur-1)

        cables = ""
        for i in range(len(self.cable)):
            if i%2==1:
                cables+=self.cable[i]+" "
            else:
                cables+=self.cable[i]
        self.option_window.set_cable(cables[:-1])

        self.option_window.button.clicked.connect(self.set_enigma_var)
        

    def set_enigma_var(self):
        if self.verify_cable() or self.option_window.cable.text()=="":
            self.rotor = [self.option_window.rotor_l.currentIndex()+1,self.option_window.rotor_c.currentIndex()+1,self.option_window.rotor_r.currentIndex()+1]
            self.reflecteur = self.option_window.reflector.currentIndex()+1
            self.inital_letters = [self.option_window.letter_l.currentText(),self.option_window.letter_c.currentText(),self.option_window.letter_r.currentText()]
            self.cable = self.option_window.cable.text().upper().replace(" ","")

            self.plaintext = ""
            self.text_edit.setText("")
            self.text_box.setText("")
            

    def verify_cable(self):
        cables_places =[0 for _ in range(26)]

        cables = self.option_window.cable.text().upper()

        for cable in cables.split(" "):
            if len(cable)!=2 or (not cable.isalpha()):
                self.option_window.error = ErrorWindow("INVALID FROMAT CABLE")
                return False
            cables_places[ALPHABET.index(cable[0])]+=1
            cables_places[ALPHABET.index(cable[1])]+=1

        if len(cables.split(" "))>5:
            self.option_window.error = ErrorWindow("YOU CAN PUT MAXIMUM 5 \nTIMES THE CABLES")

        problem = ""
        ok = True
        for i in range(len(cables_places)):
            if cables_places[i]>1:
                problem+=str(cables_places[i])+" "+ALPHABET[i]+"  "
                ok = False
        if ok==False:
            self.option_window.error = ErrorWindow("YOU CAN USE ONE TIME \nFOR EVERY LETTER\nYOU USED  "+problem)
            return False
        return True

        



app = QApplication(sys.argv)
UIWindow = UI()
app.exec_()