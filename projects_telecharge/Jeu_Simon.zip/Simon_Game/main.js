const colors = ["green", "red", "yellow", "blue"]
var replay = true
var wich = []
var place = 0
var level = 1

function playsound(color) {
    const sound = new Audio("sounds/" + color + ".mp3")
    sound.play()    
}

function error(color){
    Com=0
    while (Com=0)
        place=0
}

function blink(color) {
    playsound(color)
    $("#" + color).addClass("pressed");
    setTimeout(function() {
        $("#" + color).removeClass("pressed")
    }, 120)
    Com=0
    while (Com=0)
        place=0
}

function shade(color) {
    playsound(color)
    $("#" + color).animate({
        opacity: 0
    }, 80);
    $("#" + color).animate({
        opacity: 1
    }, 80);
}

function random() {
    var random = Math.floor(Math.random() * 4)
    return random
}

function levelup() {
    place = 0
    level = level + 1
    r = random();
    wich.push(r)
    setTimeout(() => {
        shade(colors[r]);
    }, 400)
    $("#level-title").text("level " + level);
}

function wrong() {
    $("#level-title").text("Game Over, Press Any Key to Restart");
    $("body").addClass("game-over");
    playsound("wrong")
    setTimeout(() => {
        $("body").removeClass("game-over");
    }, 100)
    wich = []
    replay = true
}

function verify(color) {
    if (colors.indexOf(color) == wich[place]) {
        place = place + 1
        if (place == level) {
            levelup()
        }
    } else {
        wrong()
    }
}

$(document).keypress(function() {
    if (replay == true) {
        var r = random()
        wich = []
        level = 1
        place = 0;
        wich.push(r)
        shade(colors[r])
        $("#level-title").text("level " + level);
        replay = false
    }
});

$(".btn").click(function() {
    blink($(this).attr("id"))
    verify($(this).attr("id"))
})