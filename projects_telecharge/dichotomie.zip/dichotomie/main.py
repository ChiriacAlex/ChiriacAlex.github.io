import sys

from PyQt5.QtCore import QUrl
from PyQt5.QtWidgets import *
from PyQt5.QtMultimedia import QMediaPlayer,QMediaContent
from PyQt5 import uic

from random import randint

class UI(QMainWindow):
    def __init__(self):
        super(UI,self).__init__()
        uic.loadUi("graphic/MainWindow.ui",self)
        
        self.random_nb = randint(1,100)
        self.first = 1
        self.last = 100
        self.tries = 0

        self.first_nb = self.findChild(QLineEdit,"premiere")
        self.last_nb = self.findChild(QLineEdit,"derniere")
        self.try_nb = self.findChild(QLineEdit,"nb_essaie")
        self.bn_start = self.findChild(QPushButton,"start")
        self.bn_try = self.findChild(QPushButton,"try_2")
        self.message = self.findChild(QLabel,"plus_moins")
        self.message_2 = self.findChild(QLabel,"dico")

        self.bn_try.setEnabled(False)
        self.bn_start.clicked.connect(self.start_game)
        self.bn_try.clicked.connect(self.try_win)

        self.show()
    def message_error(self,msg):
        self.msg_error = uic.loadUi("graphic/msg_error.ui")
        self.msg_error.findChild(QLabel,"message").setText(msg)
        self.msg_error.show()

    def play_audio(self,link):
        self.media_player = QMediaPlayer()

        url = QUrl.fromLocalFile("audio/"+link+".mp3")
        content = QMediaContent(url)
        self.media_player.setMedia(content)

        self.media_player.play()
    def dicothomie(self):
        l = [i for i in range(self.first,self.last+1)]
        gauche =0
        droite = len(l)-1
        ok=0

        while gauche<=droite:
            milieu = (gauche+droite)//2
            ok +=1
            if l[milieu]==self.random_nb:
                self.tries = ok+1
                return ok+1
            elif l[milieu]>self.random_nb:
                droite = milieu-1
            else:
                gauche = milieu+1

    def start_game(self):
        try:
            first = int(self.first_nb.text())
            last = int(self.last_nb.text())

            if first <last:
                self.random_nb = randint(first,last)
                self.first = first
                self.last = last
            else:
                self.message_error("Mets comme il faut, petit con")
                self.play_audio("no_audio")

            self.message.setStyleSheet("color: black;")  
            self.message.setText("Ca comence")
            self.bn_try.setEnabled(True)
            self.play_audio("commence")
            self.message_2.setText(f"Si t'est chaud,tu le fais en {self.dicothomie()} essaies")
        except:
            self.message_error("Mets un nombre valide")
            self.play_audio("no_audio")

    def try_win(self):
        try:
            essie = int(self.try_nb.text())
            if essie<self.first or essie>self.last:
                self.message_error("Mets un nombre entre l'intervalle")
                self.play_audio("no_audio")
                return None

            self.tries -= 1
            if self.tries>0:
                
                self.message_2.setText(f"Encore {self.tries} essaies")
            else:
                self.message_2.setText("C'est pas ouf, gagnes au moins")

            if essie < self.random_nb:
                self.message.setStyleSheet("color: rgb(170, 0, 0);")
                self.play_audio("plus")
                self.message.setText("C'est plus")

            elif essie > self.random_nb:
                self.message.setStyleSheet("color: rgb(170, 0, 0);")
                self.message.setText("C'est moins")
                self.play_audio("moins")

            else:
                self.message.setStyleSheet("color: rgb(0, 170, 0);")
                self.message.setText("T'as gagne")
                self.play_audio("gagne")
                if self.tries>-1:
                    self.message_2.setText("Et t'est chaud")
                else:
                    self.message_2.setText("Mais t'est pas chaud ,courage")

        except:
            self.message_error("Mets un nombre valide")
            self.play_audio("no_audio")

if __name__ == "__main__":
    app =  QApplication(sys.argv)
    window = UI()
    app.exec_()