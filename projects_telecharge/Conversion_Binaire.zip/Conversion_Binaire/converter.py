from tkinter import *

binary_l = []

# On affiche les résultats
def affiche_results(r1, r2, r3):
    for i in range(32):
        binary_l[i].config(text=" " + r2[i] + " ")
    e1.delete(0, END)
    e1.insert(0, r1)
    e2.delete(0, END)
    e2.insert(0, r2)
    e3.delete(0, END)
    e3.insert(0, r3)

    error1.config(text="")
    error2.config(text="")
    error3.config(text="")


# Il va convertir un réel dans les autres format
def get_entier():
    nb_reel = e1.get()
    nb_reel = nb_reel.replace(",", ".")
    try:
        # On prend la partie entière et fractionnaire et la signe
        if not ("." in nb_reel):
            nb_reel = nb_reel + ".0"
        if "-" in nb_reel:
            part_entier = int(nb_reel[1 : nb_reel.find(".")])
            signer = "-"
            signe = "1"
        else:
            part_entier = int(nb_reel[0 : nb_reel.find(".")])
            signer = ""
            signe = "0"
        part_frac = float("0" + nb_reel[nb_reel.find(".") :])
        result_simple = entier_simple(part_entier, part_frac, signe)
        result_binaire = (
            signer
            + entier_binaire(part_entier)
            + "."
            + fractioner_binaire(part_frac, 23)
        )

        affiche_results(nb_reel, result_simple, result_binaire)

    except ValueError:
        error1.config(text="Invalid nomber")


# Il va convertir binaire IEEE-754 simple précision dans les autres format
def get_binarys():
    nb_binary = e2.get()
    # On verifie si le nombre est binaire IEEE-754 simple précision
    if len(nb_binary) != 32:
        error2.config(text="Invalid nomber")
        return
    for i in nb_binary:
        if i != "1" and i != "0":
            error2.config(text="Invalid nomber")
            return

    result_reel = str(simple_entier(nb_binary))
    if "-" in result_reel:
        signe = "-"
        result_reel = result_reel.replace("-", "")
    else:
        signe = ""
    part_entier, part_frac = result_reel.split(".")
    part_entier = int(part_entier)
    part_frac = float("0." + part_frac)
    result_binaire = (
        signe + entier_binaire(part_entier) + "." + fractioner_binaire(part_frac, 23)
    )

    affiche_results(signe + result_reel, nb_binary, result_binaire)


# Il va convertir binaire virgule fixe dans les autres format
def get_binaryf():
    nb_binaire = e3.get()
    nb_binaire = nb_binaire.replace(",", ".")
    try:
        # On prend la partie entière et fractionnaire et la signe
        if not ("." in nb_binaire):
            nb_binaire = nb_binaire + ".0"
        if "-" in nb_binaire:
            nb_binaire = nb_binaire.replace("-", "")
            signer = "-"
            signe = "1"
        else:
            signer = ""
            signe = "0"
        part_entier = nb_binaire[0 : nb_binaire.find(".")]
        part_frac = nb_binaire[nb_binaire.find(".") + 1 :]
        for i in part_entier:
            if i != "1" and i != "0":
                error3.config(text="Invalid nomber")
                return
        for i in part_frac:
            if i != "1" and i != "0":
                error3.config(text="Invalid nomber")
                return
        entier = 0
        rang = 0
        frac = 0
        # On convert le binaire en parti fractionnaire d'un nombre réelle
        for i in part_frac:
            rang = rang - 1
            frac = frac + int(i) * 2**rang
        rang = 0
        # On convert le binaire en parti entière d'un nombre réelle
        for i in part_entier[::-1]:
            entier = entier + int(i) * 2**rang
            rang = rang + 1
        result_simple = entier_simple(entier, frac, signe)

        affiche_results(signer + str(frac + entier), result_simple, signer + nb_binaire)

    except ValueError:
        error3.config(text="Invalid nomber")


# On utilise ce fonction pour convertir la partie entière d'un reele en binaire
def entier_binaire(x):
    binary = ""
    if x == 0:
        return "0"
    while x != 0:
        if x % 2 != 0:
            binary = binary + "1"
        else:
            binary = binary + "0"
        x = x // 2
    return binary[::-1]


# On utilise ce foction pour convertir la partie fractionaire d'un reele en binaire
#t est la limite de ciffres de partie fractionaire
def fractioner_binaire(y, t):
    binary = ""
    if y == 0:
        return "0"
    for i in range(t):
        y = y * 2
        if y >= 1:
            binary = binary + "1"
            if y == 1:
                return binary
            y = y - 1
        else:
            binary = binary + "0"

    return binary


# On utilise cette fonction pour convertir de binaire IEEE-754 simple précision en réelle, mais pour certain nombre, on ne va pas avoir le résultat précis
def simple_entier(nb):
    n = 0
    rang = 0
    entier = 0
    # On calcul la mantisse
    for i in nb[9:33]:
        rang = rang - 1
        n = n + int(i) * 2**rang
    n = n + 1
    rang = 8
    # On calcul l'exposant
    for i in nb[1:9]:
        rang = rang - 1
        entier = entier + int(i) * 2**rang
    # On calcul le singe
    if nb[0] == "1":
        return -1 * n * 2 ** (entier - 127)
    # On calcul le nombre reele
    return n * 2 ** (entier - 127)


# On utilise ce fonction pour convertir un nombre reel en binaire norme IEEE-754 simple précision
# #x est le partie entier de nombre,y la partie fractionaire et s la signe
def entier_simple(x, y, s):
    e = 0
    exposant = ""
    # On calcul l'exposant si x plus petit que 0
    if x < 1:
        while y < 1 and e > -127:
            e = e - 1
            y = y * 2
        y = y - 1
    # On calcul l'exposant si x plus grand que 0
    else:
        nb = entier_binaire(x)
        e = len(nb) - 1
        exposant = exposant + nb[1 : e + 1]
    # Calcul d'exposant et mantisse
    # On ajoute des 0 si on a pas asses cifres pour la representation binaire.
    exposant = exposant + fractioner_binaire(y, 23 - len(exposant))
    exposant = exposant + "0" * (23 - len(exposant))
    mantisse = entier_binaire(e + 127)
    mantisse = "0" * (8 - len(mantisse)) + mantisse

    # On uni le signe,l'exposant et la mantisse pour cree le resultat
    return s + mantisse + exposant


# La partie graphique
window = Tk()
window.geometry("610x480")
window.title("Binary converter")
window.iconbitmap("image.ico")

Label(window, text="Convert a real nomber in binary ", font=("Arial", 15)).grid(
    row=0, column=0, columnspan=16, sticky="W"
)

Label(window, text="Real nomber").grid(
    row=1, column=0, columnspan=12, pady=20, sticky="W"
)
e1 = Entry(window, width=40)
e1.grid(row=1, columnspan=12, column=5, pady=20)
but1 = Button(window, text="Convert", command=get_entier).grid(
    row=1, columnspan=12, column=13, pady=20
)
error1 = Label(window, text="")
error1.grid(row=1, column=22, columnspan=12, pady=20, sticky="W")

t = Canvas(window, width=610, height=3)
t.create_rectangle(0, 0, 610, 100, fill="black", outline="black")
t.grid(column=0, row=3, columnspan=32, sticky="W")

Label(window, text="In IEEE-754", font=("Arial", 15)).grid(
    row=4, column=0, columnspan=6, pady=20, sticky="W"
)

Label(window, text="Binary nomber").grid(
    row=5, column=0, columnspan=12, pady=20, sticky="W"
)
e2 = Entry(window, width=40)
e2.grid(row=5, columnspan=12, column=5, pady=20)
but2 = Button(window, text="Convert", command=get_binarys).grid(
    row=5, columnspan=12, column=13, pady=20
)
error2 = Label(window, text="")
error2.grid(row=5, column=22, columnspan=12, pady=20, sticky="W")

Label(window, text="Sign", fg="red").grid(row=6, column=0, columnspan=2)
Label(window, text="Exponent", fg="gray").grid(row=6, column=2, columnspan=8)
Label(window, text="Mantissa", fg="blue").grid(row=6, column=17, columnspan=8)


for i in range(0, 32):
    if i == 0:
        binary_l.append(Label(window, text=" 0 ", fg="red"))
    elif i >= 1 and i <= 8:
        binary_l.append(Label(window, text=" 0 ", fg="gray"))
    else:
        binary_l.append(Label(window, text=" 0 ", fg="blue"))
    binary_l[i].grid(row=7, column=i)

t = Canvas(window, width=610, height=3)
t.create_rectangle(0, 0, 610, 100, fill="black", outline="black")
t.grid(column=0, row=8, columnspan=32, pady=20, sticky="W")

Label(window, text="In fixed point", font=("Arial", 15)).grid(
    row=9, column=0, columnspan=6, sticky="W"
)

Label(window, text="Binary nomber").grid(
    row=10, column=0, columnspan=12, pady=20, sticky="W"
)
e3 = Entry(window, width=40)
e3.grid(row=10, columnspan=12, column=5, pady=20)
but3 = Button(window, text="Convert", command=get_binaryf).grid(
    row=10, columnspan=12, column=13, pady=20
)
error3 = Label(window, text="")
error3.grid(row=10, column=22, columnspan=12, pady=20, sticky="W")

window.mainloop()
