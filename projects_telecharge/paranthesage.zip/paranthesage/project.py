

class Pile:
    def __init__(self):
        self.pile = []

    def empiler(self, x):
        self.pile.append(x)

    def depiler(self):
        return self.pile.pop()

    def est_vide(self):
        return len(self.pile) == 0


def para(chaine):
    pile = Pile()
    les_indexes = []
    les_valeurs = []
    m = 0

    for ch in chaine:
        if ch == "(":
            pile.empiler(ch)
            les_indexes.append(m)
        elif ch == ")" and not pile.est_vide():
            val = pile.depiler()
            les_valeurs.append((les_indexes.pop(), m))
        elif ch == ")":
            les_valeurs.append(("non ouverte", m))
        m = m+1

    while not pile.est_vide():
        pile.depiler()
        les_valeurs.append((les_indexes.pop(), "non ferme"))
    text = ""

    return les_valeurs
