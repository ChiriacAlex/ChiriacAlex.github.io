import tkinter as tk
from tkinter import ttk
from project import para


def calculate_result():
    entry_value = entry.get("1.0", tk.END)
    result = para(entry_value)

    text = ""
    entry.tag_remove("start", "1.0", tk.END)
    for v in result:
        text += f"{str(v)},"
        if not isinstance(v[0], int):
            print(v)
            entry.tag_add("start", f"1.{v[1]}", f"1.{v[1]+1}")
        elif not isinstance(v[1], int):
            entry.tag_add("start", f"1.{v[0]}", f"1.{v[0]+1}")

    nouveau_text = ""
    l = 100
    for i in range(len(text)//l):
        nouveau_text = nouveau_text + text[l*i:l*(i+1)]+"\n"
    nouveau_text = nouveau_text + text[l*(len(text)//l):]+"\n"

    entry.tag_config("start", background="red", foreground="white")

    result_label.config(text=f"Result: {nouveau_text}")


app = tk.Tk()
app.title("Parenthésage")
window_width = 600
window_height = 250

app.geometry(f"{window_width}x{window_height}")

style = ttk.Style()
style.theme_use('clam')

entry = tk.Text(app)
entry.config(width=20, height=1)
entry.pack(pady=10, padx=20, fill='x')

calculate_button = ttk.Button(app, text="calculer", command=calculate_result)
calculate_button.pack(pady=10)

result_label = ttk.Label(app, text="Result: ")
result_label.pack(pady=10)

app.mainloop()
