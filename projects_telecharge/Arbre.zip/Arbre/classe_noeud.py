class Noeud:
    def __init__(self, cle):
        self.Cle = cle
