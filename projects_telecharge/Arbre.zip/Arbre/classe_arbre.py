from classe_noeud import Noeud
import tkinter as tk


class Arbre:
    def __init__(self, cle):
        self.Racine = Noeud(cle)
        self.Sag = "NIL"
        self.Sad = "NIL"

    def RepresentationArbre(self, space):
        print(space+self.Racine.Cle)
        if self.Sad != "NIL":
            self.Sad.RepresentationArbre(space+"   ")
        else:
            print(space+"  "+" (x)")
        if self.Sag != "NIL":
            self.Sag.RepresentationArbre(space+"   ")
        else:
            print(space+"  "+" (x)")

    def rec_arbre(self, abre, x, y, l, xf, yf):
        abre.values.append((round(x), round(y), l, self.Racine.Cle, xf, yf))
        if self.Sad != "NIL":
            self.Sad.rec_arbre(abre, x+l, y+70, l/2, x, y)

        if self.Sag != "NIL":
            self.Sag.rec_arbre(abre, x - l, y+70, l/2, x, y)

    def Representation_arbre(self):
        self.values = []
        width, height = 1000, 600
        self.rec_arbre(
            self, width//2, 50, width//4-50, "", "")

        def create_circle(canvas, x, y, radius, text):
            circle = canvas.create_oval(
                x - radius, y - radius, x + radius, y + radius, outline="black", fill="white")
            text = canvas.create_text(x, y, text=text, font=("Arial", 12))

        root = tk.Tk()
        root.title("L'arbre de Gargamel")

        canvas = tk.Canvas(root, width=width, height=height)
        canvas.pack()
        dico = self.Hauteur(self)
        lst = self.LstFeuilles(self)
        h = self.HauteurArbre(dico, lst)+1

        # for i in range(h):
        # canvas.create_line(30, 50+70*i, width, 50+70*i)
        # canvas.create_text(15, 50+70*i, text="h " +
        # str(1+i), font=("Arial", 10))

        # Other options
        dico_hauteur = self.Hauteur(self)
        taille_arbre = self.Taille(self)
        lste_feuille = self.LstFeuilles(self)
        lste_noeuds_internes = self.LstNoeudsInternes(self, lste_feuille)
        hauteur_arbre = self.HauteurArbre(dico_hauteur, lste_feuille)
        lcb = self.LC(dico_hauteur)
        lce = self.LCE(dico_hauteur, lste_feuille)
        lci = self.LCI(dico_hauteur, lste_noeuds_internes)
        pm = self.PM(lcb, self)
        pme = self.PME(lce, lste_feuille)
        pmi = self.PMI(lci, lste_feuille, self)

        canvas.create_line(90, 50+70*pm, width-50, 50+70*pm, fill="blue")

        canvas.create_line(90, 50+70*pme, width-50, 50+70*pme, fill="green")

        canvas.create_line(90, 50+70*pmi, width-50, 50+70*pmi, fill="red")

        for i in self.values:

            if i[4] != "" and i[5] != "":
                canvas.create_line(i[0], i[1], i[4], i[5])

        for i in self.values:
            create_circle(canvas, i[0], i[1], 20, i[3])
        canvas.create_text(20, height-150, text="dico_hauteur :" +
                           str(dico), font=("Arial", 10), anchor="w")
        canvas.create_text(20, height-130, text="taille_arbre: " +
                           str(taille_arbre), font=("Arial", 10), anchor="w")
        canvas.create_text(20, height-110, text="lste_feuille: " +
                           str(lste_feuille), font=("Arial", 10), anchor="w")
        canvas.create_text(20, height-90, text="lste_noeuds_internes: " +
                           str(lste_noeuds_internes), font=("Arial", 10), anchor="w")
        canvas.create_text(20, height-70, text="hauteur_arbre: " +
                           str(hauteur_arbre), font=("Arial", 10), anchor="w")
        canvas.create_text(20, height-50, text="Longueur de cheminement: " +
                           str(lcb), font=("Arial", 10), anchor="w")
        canvas.create_text(20, height-30, text="Longueur de cheminement externe: " +
                           str(lce), font=("Arial", 10), anchor="w")
        canvas.create_text(20, height-10, text="Profondeur moyenne interne " +
                           str(lci), font=("Arial", 10), anchor="w")

        canvas.create_text(30, 50+70*pmi, text="pmi " +
                           str(pmi), font=("Arial", 10), fill="red", anchor="w")
        canvas.create_text(30, 50+70*pme, text="pme " +
                           str(pme), font=("Arial", 10), fill="green", anchor="w")
        canvas.create_text(30, 50+70*pm, text="pm " +
                           str(pm), font=("Arial", 10), fill="blue", anchor="w")

        canvas.create_text(width-300, height-10, text="Copyright decembre 2023 - Chiriac Alex ",
                           font=("Arial", 13), fill="blue", anchor="w")

        root.mainloop()

    def Hauteur(self, arbre):
        dico = {}

        def rec(n, arbre):
            dico[arbre.Racine.Cle] = n
            if arbre.Sag != "NIL":
                rec(n+1, arbre.Sag)
            if arbre.Sad != "NIL":
                rec(n+1, arbre.Sad)
        rec(0, arbre)

        return dico

    def Taille(self, arbre):
        summ = 0

        def rec(arbre, summ):
            if arbre.Sag != "NIL":
                summ = summ + rec(arbre.Sag, summ)
            if arbre.Sad != "NIL":
                summ = summ + rec(arbre.Sad, summ)
            if arbre.Sad == "NIL" and arbre.Sag == "NIL":
                return 1
            return summ

        return rec(arbre, 0)

    def LstFeuilles(self, arbre):
        l = []

        def rec(arbre):
            if arbre.Sag != "NIL":
                rec(arbre.Sag)
            if arbre.Sad != "NIL":
                rec(arbre.Sad)
            if arbre.Sad == "NIL" and arbre.Sag == "NIL":
                l.append(arbre.Racine.Cle)
        rec(arbre)

        return l

    def LstNoeudsInternes(self, arbre, lste_feuille):
        l = []

        def rec(arbre):
            if arbre.Racine.Cle not in lste_feuille:
                l.append(arbre.Racine.Cle)
            if arbre.Sad != "NIL":
                rec(arbre.Sad)
            if arbre.Sag != "NIL":
                rec(arbre.Sag)

        rec(arbre)
        return l

    def HauteurArbre(self, dico, liste):
        return max([dico[x] for x in liste])

    def LC(self, dico_hauteur):
        summ = 0
        for i in dico_hauteur.values():
            summ += i
        return summ

    def LCE(self, dico, liste):
        summ = 0
        for i in liste:
            summ += dico[i]
        return summ

    def LCI(self, dico, liste):
        summ = 0
        for i in liste:
            summ += dico[i]
        return summ

    def PM(self, lcb, a):
        return round(lcb/self.Taille(a), 2)

    def PME(self, lce, lste_feuille):
        return round(lce/len(lste_feuille), 2)

    def PMI(self, lci, lste_feuille, a):
        return round(lci/(self.Taille(a)-len(lste_feuille)), 2)
