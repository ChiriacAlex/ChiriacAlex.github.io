class Jouer():
    def __init__(self,nom,mainJoueur):
        self.nom = nom
        self.mainJoueur = mainJoueur 
        self.nbCartes = len(self.mainJoueur)
    def getNom(self):
        return self.nom
    def getNbCartes(self):
        return self.nbCartes
    def jouerCarte(self):
        if self.nbCartes!=0:
            self.nbCartes-=1
            return self.mainJoueur.pop()
        return None
    def insererMain(self,cartesGanee):
        self.mainJoueur.insert(0,cartesGanee)
        self.nbCartes += 1
    