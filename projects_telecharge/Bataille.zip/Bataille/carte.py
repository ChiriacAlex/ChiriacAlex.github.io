# -*- coding: utf-8 -*-

COULEURS = ('♦', '♥', '♣', '♠')
NOM = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'Valet', 'Dame', 'Roi', 'As']
VALEURS = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, '10': 10, 'Valet': 11, 'Dame': 12, 'Roi': 13, 'As':14,"joker":15}


class Carte:
 
    def __init__(self, nom, couleur):
        # Affectation des attributs nom et couleur (avec contrôle dans un deuxième temps).
        self.__nom = nom
        self.__couleur = couleur
        self.__valeur = VALEURS[self.__nom]
        
    
    ###########################################################################
    ################# Définition des méthodes d'instances avec contrôle #######
    ###########################################################################
    def getNom(self): # getter
        return self.__nom
 
    def getCouleur(self): # getter
       return self.__couleur
     
    def getValeur(self): # getter
        return self.__valeur

    def egalite(self, deuxiemecarte):
        """ Renvoie True si les cartes ont même valeur, False sinon
        deuxiemecarte: Objet de type Carte """
        return self.getValeur() == deuxiemecarte.getValeur()

        
 
    def estSuperieureA(self, deuxiemecarte):
        """ Renvoie True si la valeur de self est supérieure à celle de carte,
        False sinon
        deuxiemecarte: Objet de type Carte """
        return self.getValeur() > deuxiemecarte.getValeur()
 
    def estInferieureA(self, deuxiemecarte):
        """ Renvoie True si la valeur de self est inferieure à celle de carte,
        False sinon
        deuxiemecarte: Objet de type Carte """
        return self.getValeur() < deuxiemecarte.getValeur()
 
    def affichageCarte(self):
        """ affiche la carte caractérisee par son nom et sa couleur et retourne une chaine de caractères """
        return f"{self.__nom} de {self.__couleur}"
        
    
    def __repr__(self):
        """ Pour pouvoir faire afficher la carte avec print(carte).
        Par exemple, pour une carte de nom Dame et de couleur ♥
        caractérisée par l'objet maCarte, 
        l'instruction print(maCarte) --> Dame de ♥ """
        return self.affichageCarte()
    
    
if __name__ == "__main__":     # Test de la classe Carte
    carte1 = Carte('Dame','♥')
    print(carte1)
    carte2 = Carte('Roi','♣')
    print(carte2)
    print(carte1.estInferieureA(carte2))
    print(carte1.estSuperieureA(carte2))
    print(carte2.estSuperieureA(carte1))
    print(carte2.estInferieureA(carte1))