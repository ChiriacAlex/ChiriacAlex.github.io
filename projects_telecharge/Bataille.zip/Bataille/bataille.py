from jeu import JeuCartes
from jouer import Jouer
from random import shuffle

class Bataille():
    def __init__(self,nom1,nom2,nbcartes=52):
        self.mon_jeu = JeuCartes(nbcartes)
        self.mon_jeu.melanger()
        paquet1,paquet2 = self.mon_jeu.distribuerJeu(2,self.mon_jeu.getTailleJeu()//2)
        self.jouer1 = Jouer(nom1,paquet1)
        self.jouer2 = Jouer(nom2,paquet2)

    def tire_carte(self):
        carte1 = self.jouer1.jouerCarte()
        carte2 = self.jouer2.jouerCarte()
        return carte1,carte2

    def round(self,carte1,carte2):
        
        
        if carte1.getValeur()>carte2.getValeur():
            cartes = [carte1,carte2]
            shuffle(cartes)
            carte1 = cartes[0]
            carte2 = cartes[1]
            self.jouer1.insererMain(carte1)
            self.jouer1.insererMain(carte2)
            return 1
        elif carte1.getValeur()<carte2.getValeur():
            cartes = [carte1,carte2]
            shuffle(cartes)
            carte1 = cartes[0]
            carte2 = cartes[1]
            self.jouer2.insererMain(carte1)
            self.jouer2.insererMain(carte2)
            return 2
        else:
            return 3
        

    def gagnant(self):
        if self.jouer1.getNbCartes() == 0:
            return 2
        elif self.jouer2.getNbCartes() ==0:
            return 1
        else:
            return None

