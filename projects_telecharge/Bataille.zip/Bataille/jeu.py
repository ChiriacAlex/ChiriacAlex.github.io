# -*- coding: utf-8 -*-
from carte import *
from random import *

COULEURS = ('♦', '♥', '♣', '♠')
NOM = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'Valet', 'Dame', 'Roi', 'As']
VALEURS = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, '10': 10, 'Valet': 11, 'Dame': 12, 'Roi': 13, 'As':14}


class JeuCartes():
    
    def __init__(self, nbCartes=52):
        # Le jeu doit comporter 32 ou 52 cartes, effectuer un contrôle
        self.nbCartes = nbCartes
        self.jeu = [] # self.jeu est une liste des self.nbCartes
        self.creerJeu() # on appelle la méthode adequate qui fera le boulot
        
 
    ###########################################################################
    ################# Définition des méthodes d'instances #####################
    ###########################################################################
    def getTailleJeu(self):
        """ Fonction qui retourne le nombre de cartes du jeu
        Valeur retournée: type int """
        return len(self.jeu)

 
    def creerJeu(self): # utilise des objet
        """Créée la liste des cartes de l'attribut self.jeu.
        Lors de cette création, les cartes sont rangés dans un ordre prédéfini.
        On exploitera les attributs de la classe Carte se trouvant dans le fichier python 'carte.py'
        Pour la suite, la liste de cartes pourra être vue comme une pile:
             l'indice 0 est la carte la plus en dessous,
             l'indice le plus élevé correspondant à la carte du dessus qui pourra être distribuée par la suite """
        if self.nbCartes!=54:
            self.jeu = []
            for couleur in COULEURS:
                for x in range(13-int(self.nbCartes/4),13):
                    self.jeu.append(Carte(NOM[x],couleur))
        else:
            self.jeu = []
            for couleur in COULEURS:
                for x in range(13-int((self.nbCartes-2)/4),13):
                    self.jeu.append(Carte(NOM[x],couleur))
        
            self.jeu.append(Carte("joker","rouge"))
            self.jeu.append(Carte("joker","noir"))
    def getJeu(self):
        """ Renvoie la liste des cartes correspondant à l'attribut self.jeu """
        return self.jeu
         
    def melanger(self): # utiliser une fonction tout faite se trouvant dans le module random ...
        """ Mélange sur place les cartes de la liste des cartes associée au champ self.jeu """
        
        shuffle(self.jeu)
        
         
    def distribuerCarte(self):
        """ Cette fonction permet de distribuer une carte à un joueur. Elle retourne la carte
        Valeur retournée: Objet de type Carte """
        return self.jeu.pop()
 
    def distribuerJeu(self, nbJoueurs, nbCartes):
        """ Cette méthode distribue nbCartes à chacun des nbJoueurs,
        Cela reviendra à retourner un tableau à nbJoueurs lignes et nbCartes colonne contenant les cartes """
        m=[]
        for _ in range(nbJoueurs):
            l = []
            for _ in range(nbCartes):
                l.append(self.distribuerCarte())
            m.append(l)
        self.creerJeu()
        return m


if __name__ == "__main__":     # Test de la classe JeuCartes
    mon_jeu = JeuCartes(32)
    print(mon_jeu)
    lepaquet = mon_jeu.getJeu()
    print("--------------------------------------------------------------------------------")
    print("Paquet de cartes créé :")
    print("--------------------------------------------------------------------------------")
    for i in range(len(lepaquet)):
        print(lepaquet[i].affichageCarte())
    mon_jeu.melanger()
    print("--------------------------------------------------------------------------------")
    print("Paquet de cartes mélangé :")
    print("--------------------------------------------------------------------------------")
    for i in range(len(lepaquet)):
        print(lepaquet[i].affichageCarte())
    print("--------------------------------------------------------------------------------")
    
    jeu_divise = mon_jeu.distribuerJeu(2,16)
    for i in range(len(jeu_divise)):
        print("----------------------> jeu "+str(i+1))
        for j in range(len(jeu_divise[i])):
            print(jeu_divise[i][j].affichageCarte())
    
