from tkinter import *
from tkinter import ttk
from PIL import ImageTk, Image
from bataille import Bataille

COULEURS = ('♣','♦', '♥' ,'♠')
NOM = ['10','2', '3', '4', '5', '6', '7', '8', '9', 'As', 'Valet', 'Roi', 'Dame']

class mainwindow(object):
    def __init__(self):
        
        self.is_save = False
        self.nom1 = ""
        self.nom2 = ""
        self.score1 = 16
        self.score2 = 16
        self.nombre_cartes = 52
        self.mon_bataille = ""
        self.cart1_pose = ""
        self.cart2_pose = ""
        self.tire = 0
        self.cartes_pose = []

        self.root = Tk()
        self.root.minsize(width = 800,height = 550)
        self.root.maxsize(width = 800,height = 550)
        self.root.title("Jeux des cartes")
        self.root.config(highlightbackground="black", highlightthickness=2)

        image = Image.open("images/background.png")
        bg = ImageTk.PhotoImage(image)
        self.root.my_canvas = Canvas(width=793,height=543)
        
        self.root.my_canvas.create_image(0, 0, image=bg)
        self.root.my_canvas.place(x=0,y=0)

        self.root.jouer_nom_1 = Label(text="Alex Chiriac ",borderwidth=2,relief="solid",font=("Ariel",14,""),padx=10,pady=5,width=10)
        self.root.jouer_nom_1.grid(row=0,column=0,padx=10)
        self.root.score_jouer_1 = Label(text="Score: 12",borderwidth=2,relief="solid",font=("Ariel",14,""),padx=10,pady=5)
        self.root.score_jouer_1.grid(row=0,column=1,pady=30)
        self.root.nb_places = Label(text="Tires : 0",borderwidth=2,relief="solid",font=("Ariel",14,""),padx=10,pady=5,fg="green")
        self.root.nb_places.grid(row=0,column=2,pady=30)
        self.root.jouer_nom_2 = Label(text="Alex",borderwidth=2,relief="solid",font=("Ariel",14,""),padx=10,pady=5,width=10)
        self.root.jouer_nom_2.grid(row=0,column=4,padx=10)
        self.root.score_jouer_2 = Label(text="Score: 12",borderwidth=2,relief="solid",font=("Ariel",14,""),padx=10,pady=5)
        self.root.score_jouer_2.grid(row=0,column=3)
        
        self.imgs = {}
        self.imgs["back"] = ImageTk.PhotoImage(Image.open(f"images/back.jpg").resize((125,182),Image.LANCZOS))
        for i in NOM:
            for j in COULEURS:
                self.imgs[f"{i}_{j}"] = ImageTk.PhotoImage(Image.open(f"images/{i}_{j}.png").resize((125,182),Image.LANCZOS))
        self.imgs["joker_noir"] = ImageTk.PhotoImage(Image.open(f"images/black_joker.png").resize((125,182),Image.LANCZOS))
        self.imgs["joker_rouge"] = ImageTk.PhotoImage(Image.open(f"images/red_joker.png").resize((125,182),Image.LANCZOS))
        
        self.root.carte1_pose = Label(image="",borderwidth=2,relief="solid")
        self.root.carte1_pose.grid(row=1,column=1,pady=40,padx=13)
        self.root.carte1 = Label(image="",borderwidth=2,relief="solid")
        self.root.carte1.grid(row=1,column=0,pady=40,padx=13)
        
        self.console = Label(text="Alex",relief="solid",bg="Black",fg="white",width=22,height=14,font=("Ariel",8,""),anchor="n")
        self.console.grid(row=1,column=2,pady=40,padx=15)

        self.root.carte2_pose = Label(image="",borderwidth=2,relief="solid")
        self.root.carte2_pose.grid(row=1,column=3,pady=40,padx=13)
        self.root.carte2 = Label(image="",borderwidth=2,relief="solid")
        self.root.carte2.grid(row=1,column=4,pady=40,padx=13)

        self.root.button = Button(text="JOUER",padx=10,pady=10,background="light green",font=("Ariel",14,"bold"),command=self.play)
        self.root.button.grid(row=2,column=2,padx=20)

        self.root.button_settings = Button(text="PARAMETRES",padx=5,pady=5,background="white",font=("Ariel",10,"bold"),command=self.open_settings)
        self.root.button_settings.grid(row=3,column=0,padx=20,pady=70)
        self.root.button_recommancer = Button(text="RECOMMENCER",padx=5,pady=5,background="white",font=("Ariel",10,"bold"),command=self.restart)
        self.root.button_recommancer.grid(row=3,column=1,padx=20,pady=70)

        self.open_settings()

        self.root.mainloop()

        

    def open_settings(self):
        self.root.withdraw()

        self.settings = Toplevel()

        self.title_text = Label(self.settings,text="Il faut completer ca pour jouer",font=("Ariel",12,"bold"))
        self.title_text.grid(row=0,column=0,columnspan=3)
        
        self.settings.title("Parametres")
        self.settings.minsize(width = 400,height = 300)
        self.settings.maxsize(width = 400,height = 300)
        self.settings.config(padx=20,pady=20)

        self.settings.nom1 = Label(self.settings,text="Nom du joueur 1 :",font=("Ariel",12,""))
        self.settings.nom1.grid(row=1,column=0,sticky="W")
        self.settings.e1_nom = Entry(self.settings)
        self.settings.e1_nom.grid(row=1,column=1,padx=10,pady=10)
        self.settings.e1_nom.insert(0, "Alex") 

        self.settings.nom2 = Label(self.settings,text="Nom de joueur 2 :",font=("Ariel",12,""))
        self.settings.nom2.grid(row=2,column=0,sticky="W")
        self.settings.e2_nom = Entry(self.settings)
        self.settings.e2_nom.grid(row=2,column=1,padx=10,pady=10)
        self.settings.e2_nom.insert(0, "Prof") 

        self.settings.text_nombre_cartes= Label(self.settings,text="Nombre Cartes :",font=("Ariel",12,""))
        self.settings.text_nombre_cartes.grid(row=3,column=0)

        self.settings.value = StringVar()
        self.settings.value.set("32") 
        self.settings.cartes = ttk.Combobox(self.settings, width = 10, textvariable = self.settings.value,state= "readonly")
        self.settings.cartes['values'] = ('54','52',  '32') 
        self.settings.cartes.grid(row=3,column=1,padx=10,pady=10,sticky="W")

        self.settings.button_sauvegarde = Button(self.settings,text="SAUVEGARDE",padx=5,pady=5,background="white",font=("Ariel",10,"bold"),command=self.start_game)
        self.settings.button_sauvegarde.grid(row=4,column=0,padx=5,pady=80)
        self.settings.button_sort = Button(self.settings,text="SORT",padx=5,pady=5,background="white",font=("Ariel",10,"bold"),command=self.close_settings)
        self.settings.button_sort.grid(row=4,column=2,padx=10,pady=80)

        if self.is_save == False:
            self.settings.button_sort["state"] = "disabled"

        self.settings.protocol("WM_DELETE_WINDOW", lambda: self.root.destroy())
    def close_settings(self):
        self.settings.withdraw()
        self.root.deiconify()
    
    def start_game(self):
        self.nom1 = self.settings.e1_nom.get()
        self.nom2 = self.settings.e2_nom.get()
        self.nombre_cartes = self.settings.value.get()

        if self.nom1 == "" or self.nom2 == "" or self.nombre_cartes == "":
            self.error_message("Il faut completer tous les cas")
        elif len(self.nom1) >=12 or  len(self.nom2) >=12:
            self.error_message("Les noms sont de maximum \n 12 characteres")
        else:
            self.nombre_cartes = int(self.nombre_cartes)
            self.is_save = True
            self.close_settings()
            self.restart()
    def restart(self):
        self.score1,self.score2 = (int(self.nombre_cartes/2),int(self.nombre_cartes/2))
        self.root.jouer_nom_1.config(text = self.nom1)
        self.root.jouer_nom_2.config(text = self.nom2)
        self.root.score_jouer_1.config(text = f"Nb. Cartes : {self.score1}")
        self.root.score_jouer_2.config(text = f"Nb. Cartes : {self.score2}")
        self.tire = 0
        self.root.nb_places.config(text = f"Tires : {self.tire}")
        self.console.config(text="")

        self.root.carte1_pose.configure(image = self.imgs["back"] )
        self.root.carte1.configure(image = self.imgs["back"] )
        self.root.carte2_pose.configure(image = self.imgs["back"] )
        self.root.carte2.configure(image = self.imgs["back"] )

        self.destroy_cartes()

        self.mon_bataille = Bataille(self.nom1,self.nom2,self.nombre_cartes)
    def update(self):
        self.root.carte1_pose.config(image = self.imgs[ self.cart1_pose] )
        self.root.carte2_pose.config(image = self.imgs[ self.cart2_pose]  )
        self.root.nb_places.config(text = f"Tires : {self.tire}")

        self.root.score_jouer_1.config(text = f"Nb. Cartes : {self.score1}")
        self.root.score_jouer_2.config(text = f"Nb. Cartes : {self.score2}")
    def poser_carte(self,carte1,carte2,is_tourne):
        if is_tourne ==True:
            carte1 = "back"
            carte2 = "back"

        self.cartes_pose.append(Label(image=self.imgs[carte1],borderwidth=2,relief="solid"))
        self.cartes_pose.append(Label(image=self.imgs[carte2],borderwidth=2,relief="solid"))
        y_plus = 22 *(int(len(self.cartes_pose)/2))
        x_plus = 4 *(int(len(self.cartes_pose)/2))
        self.cartes_pose[-1].place(x=171-x_plus,y=144+y_plus)
        self.cartes_pose[-2].place(x=497+x_plus,y=144+y_plus)
    def destroy_cartes(self):
        for i in self.cartes_pose:
            i.destroy()
        self.cartes_pose = []

    def play(self):
        self.destroy_cartes()
        message_text=""
        if self.mon_bataille.gagnant()==None:
            
            self.console.config(text="")
                
            carte1,carte2 = self.mon_bataille.tire_carte()
            self.cart1_pose = f"{carte1.getNom()}_{carte1.getCouleur()}"
            self.cart2_pose = f"{carte2.getNom()}_{carte2.getCouleur()}"

            gagne = self.mon_bataille.round(carte1,carte2)

            message_text+=f"{self.nom1} joue {carte1.affichageCarte()}\n"
            message_text+=f"{self.nom2} joue {carte2.affichageCarte()}\n"
            bataille = []
            if gagne==3 and self.mon_bataille.gagnant()==None:
                bataille.append(carte1)
                bataille.append(carte2)

                while gagne ==3 and self.mon_bataille.gagnant()==None:
                    message_text+=(f"bataille \n")
                    carte1,carte2 = self.mon_bataille.tire_carte()
                    self.poser_carte("","",True)
                    
                    message_text+=f"{self.nom1} pose {carte1.affichageCarte()}\n"
                    message_text+=f"{self.nom2} pose {carte2.affichageCarte()}\n"

                    bataille.append(carte1)
                    bataille.append(carte2)
                    if self.mon_bataille.gagnant()!=None:
                        break
                    
                    carte1,carte2 = self.mon_bataille.tire_carte()

                    cart1_pose = f"{carte1.getNom()}_{carte1.getCouleur()}"
                    cart2_pose = f"{carte2.getNom()}_{carte2.getCouleur()}"

                    self.poser_carte(cart2_pose,cart1_pose,False)

                    self.write_console(f"{self.nom1} joue {carte1.affichageCarte()}")
                    self.write_console(f"{self.nom2} joue {carte2.affichageCarte()}")

                    message_text+=f"{self.nom1} joue {carte1.affichageCarte()}\n"
                    message_text+=f"{self.nom2} joue {carte2.affichageCarte()}\n"

                    gagne = self.mon_bataille.round(carte1,carte2)
                    if gagne == 3:
                        bataille.append(carte1)
                        bataille.append(carte2)
                if gagne==1:
                    for i in bataille:
                        self.mon_bataille.jouer1.insererMain(i)
                elif gagne==2:
                    for i in bataille:
                        self.mon_bataille.jouer2.insererMain(i)
            if gagne==1:
                message_text+=f"{self.mon_bataille.jouer1.getNom()} gagne le round\n"
                
            elif gagne==2:
                message_text+=f"{self.mon_bataille.jouer2.getNom()} gagne le round\n"
                
        
            self.score1 = self.mon_bataille.jouer1.getNbCartes()
            self.score2 = self.mon_bataille.jouer2.getNbCartes()
            self.tire+=1
        if self.mon_bataille.gagnant()!=None:
            self.cart1_pose = "back"    
            self.cart2_pose = "back"             
            self.root.carte1.configure(image = self.imgs["back"] )
            self.root.carte2.configure(image = self.imgs["back"] )

            self.destroy_cartes()
            if self.mon_bataille.gagnant()==1:
                self.score1 = self.nombre_cartes
                message_text+=f"{self.nom1} a gagne le match"
            else:
                self.score2 = self.nombre_cartes
                message_text+=f"{self.nom2} a gagne le match"
        self.write_console(message_text)
        self.update()
    
    def write_console(self,text1):
        self.console.config(text=f"{text1}")
    def error_message(self,error_text):
        def disable_sauvegarde():
            self.settings.button_sauvegarde["state"] = "active"
            self.error.destroy()
        self.settings.button_sauvegarde["state"] = "disabled"

        self.error = Toplevel()

        self.title_text = Label(self.error,text=error_text,font=("Ariel",14,"bold"),fg="red")
        self.title_text.grid(row=0,column=0,columnspan=3)
        self.error.minsize(width = 300,height = 150)
        self.error.maxsize(width = 300,height = 150)
        self.error.title("Error")
        self.error.protocol("WM_DELETE_WINDOW", lambda: disable_sauvegarde())

if __name__ == "__main__":

    main = mainwindow()
    
    